# Operating Sistems
[![OSS](https://img.shields.io/badge/course-currently%20taking%20place-brightgreen.svg)](#subject_stage)


Subject GIISOF01-2-006 from University of Oviedo.

Here you will find the code from the labs and individual work regarding the subject of Operating Systems. This subject comes from the University of Oviedo.

See [LICENSE](/LICENSE) for more information about how can you use this code.
