Exercises done from 0 to 3.
