Done exercises from 1 to 4 both included.
