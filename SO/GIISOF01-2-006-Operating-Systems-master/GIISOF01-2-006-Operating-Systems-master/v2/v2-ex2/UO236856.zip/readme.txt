Exercises done from 0 to 7.
