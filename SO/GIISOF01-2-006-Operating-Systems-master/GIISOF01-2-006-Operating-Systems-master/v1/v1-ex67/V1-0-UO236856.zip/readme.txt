Ex 0, 1 and 2
