Done exercises from 0 to 2 both included.
