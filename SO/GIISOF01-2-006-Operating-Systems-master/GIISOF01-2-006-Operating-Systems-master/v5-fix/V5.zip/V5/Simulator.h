#ifndef SIMULADOR_H
#define SIMULADOR_H


// General constants for the simulation

// Maximum number of programs in the command line plus daemons programs
#define PROGRAMSMAXNUMBER 30


#endif
