#include <stdio.h>
#include <stdlib.h>

main () {

  printf("Hola mundo\n");
  exit(1);
}


// 1. Compilar con "gcc 01HolaMundo.c"
// 2. Ejecutar con "./a.out"
// 3. Obtener la ayuda sobre printf: "man 3 printf"
// 4. Obtener la ayuda sobre exit: "man exit"