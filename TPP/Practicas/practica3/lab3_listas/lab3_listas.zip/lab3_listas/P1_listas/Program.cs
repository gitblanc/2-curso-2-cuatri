﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConjuntoV1;
using Stackv1;

namespace P1_listas
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack st = new Stack(4);

        }
    }
}
