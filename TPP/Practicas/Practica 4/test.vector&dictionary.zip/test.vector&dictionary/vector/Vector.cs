﻿using System;
using System.Collections.Generic;

namespace vector 
{
    class Vector : IList<T>
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
