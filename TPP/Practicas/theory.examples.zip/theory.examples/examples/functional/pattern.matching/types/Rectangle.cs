﻿using System;
using System.Collections.Generic;

namespace TPP.Functional.PatternMatching {

    public class Rectangle {
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
    }

}
