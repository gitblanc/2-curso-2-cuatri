﻿using System;
using System.Collections.Generic;
using System.Text;

namespace generativeprogramming
{
    public class ScriptGlobals
    {
        public double x;
    }
}
