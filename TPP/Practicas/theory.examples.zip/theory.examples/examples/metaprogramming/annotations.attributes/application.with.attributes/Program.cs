using System;
using System.Collections.Generic;
using System.Text;

namespace TPP.ObjectOrientation.AnnotationsAttributes {

    [Author("John")]
    public class MyClass {
    }

    [Author("Mary",2, true,"07/10/2012")]
    public class Program {
        static void Main(string[] args) {
        }
    }
}
