package alg77777777.p2 ;

import alg77777777.p2.Vector;


public class Burbuja extends Vector
{
	public Burbuja(int nElementos) {
		super(nElementos);
	}

	/**
	 * Ordenación por el método de Burbuja
	 */
	@Override
	public void ordenar() {
		// TODO: Implementación del método de ordenación
	}  

	@Override
	public String getNombre() {
		return "Burbuja";
	}  
} 