package alg77777777.p2;

import alg77777777.p2.Vector;

/** Este programa sirve para ordenar n elementos
	con un algoritmo de los "malos" (cuadrático)·
	es la SELECCION
 */
public class Seleccion extends Vector
{
	public Seleccion(int nElementos) {
		super(nElementos);
	}
	

	/**
	 * Ordenación por selección
	 */
	@Override
	public void ordenar() {
		// TODO: Implementación del método de ordenación
	}  

	@Override
	public String getNombre() {		
		return "Selección";
	}  
} 
