package alg77777777.p2 ;

import alg77777777.p2.Vector;

/** Este programa sirve para ordenar n elementos
	con un algoritmo de los "malos" (cuadrático)· 
	Es la INSERCIÓN DIRECTA
 */
public class Insercion extends Vector
{
	
	public Insercion(int nElementos) {
		super(nElementos);
	}

	/**
	 * Ordenación por inserción directa
	 */
	@Override
	public void ordenar() {
		for(int i = 0; i < ele)
	} 

	@Override
	public String getNombre() {
		return "Inserción directa";
	} 
} 
