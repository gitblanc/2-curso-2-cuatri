/**
 * @author blanc
 *
 */

import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

public class Imagen {
	
	private float[][] img;
	private int width, height;
	
	/**
	 * constructor para leer una imagen de disco
	 * @param img_path ruta del archivo 
	 */
	public Imagen(String img_path) {
		try 
		{
		    BufferedImage buff_img = ImageIO.read(new File(img_path)); //lectura imagen 		    
		    //store data into a float array
		    this.width = buff_img.getWidth();
		    this.height = buff_img.getHeight();
		    Raster raster = buff_img.getData();
		    this.img = new float[width][height];
		    for (int i = 0; i < width; i++)
		        for (int j = 0; j < height; j++)
		        	this.img[i][j] = raster.getSample(i, j, 0);		    		    
		    this.zeroNormalization(); // Cero-nomalizaci�n (media de los valores de los p�xeles es cero
		                              // y su desviaci�n est�ndar es 1)
		} 
		catch (IOException e) 
		{
		    e.printStackTrace();
		}
	}
	
	/**
	 *  Constructor para generar una imagen vacia (los niveles de gris de todos los p�xeles a zero)
	 * @param width p�xeles de ancho
	 * @param height p�xeles de alto
	 */
	public Imagen(int width, int height) {//Este se va a utilizar, crea una imagen en blanco o en negro
		this.width = width;
		this.height = height;
		this.img = new float[this.width][this.height];
	}
	
	public int getWidth() {
		return this.width;
	}
	
	public int getHeight() {
		return this.height;
	}
	
	public float[][] getSignal() {
		return this.img;
	}
	
	/**
	 * Permite a�adir la se�al (niveles de gris para cada p�xel) de otra imagen
	 * La suma de dos im�genes cero-normalizadas dan como resultado otra imagen cero-nomalizada
	 * La suma de dos im�genes cero-normalizadas es un promedio en lugar de una acumulaci�n
	 * @param img imagen a a�adir
	 */
	public void addSignal(Imagen img) {//suma dos im�genes
		for (int i = 0; i < width; i++)
	        for (int j = 0; j < height; j++)
	            this.img[i][j] += img.img[i][j];
	}
	
	/**
	 * A�ade ruido, additivo Gaussiano, a los p�xles de la imagen
	 * @param noise_std desviaci�n est�ndar para el modelo de ruido
	 */
	public void addNoise(double noise_std) {
		Random rand = new Random();
	    for (int i = 0; i < width; i++)
	        for (int j = 0; j < height; j++)
	            this.img[i][j] += rand.nextGaussian() * noise_std;
	}
	
	/**
	 * Obtiene el negativo de una imagen, suponemos la imagen est� cero-normalizada
	 */
	public void invertSignal() {
		for (int i = 0; i < width; i++)
			for (int j = 0; j < height; j++)
				this.img[i][j] *= -1;
	}
	
	/**
	 *  @region indica que regi�n hay que suprimir (por los p�xeles a 0): 0-arriba, 1-abajo, 
	 *          2-izquierda and 3-derecha
	 */
	public void suppressRegion(int region) {//borra una parte de la imagen, a�ade distorsi�n a la imagen
		//suppression loop
		switch (region) {
			case 0: // remove up half
				for (int i=0; i<this.width; i++)
					for (int j=0; j<this.height/2; j++)
						this.img[i][j] = 0;
				break;
			case 1: // remove bottom half
				for (int i=0; i<this.width; i++)
					for (int j=this.height/2; j<this.height; j++)
						this.img[i][j] = 0;
				break;
			case 2: // remove left half
				for (int i=0; i<this.width/2; i++)
					for (int j=0; j<this.height; j++)
						this.img[i][j] = 0;
				break;
			default: // remove right half
				for (int i=this.width/2; i<this.width; i++)
					for (int j=0; j<this.height; j++)
						this.img[i][j] = 0;
		}
		
		// Cero-normalizaci�n
		this.zeroNormalization();
	}
	
	/** 
	 * Calcula la Correlaci�n cruzada cero normalizada (Zero Mean Normalized Cross-Correlation, ZNCC)
	 * con respecto a otra image 
	 * @param img imagen de referencia para el c�lculo de la ZNCC(img, this)
	 * @return
	 */
	public float zncc(Imagen img) {//implementa la correelaci�n cruzada
		float cc = 0;
		float std_i = 0;
		float mean_1 = this.computeMean();
		float mean_2 = img.computeMean();
		float std_1 = this.computeStd();
		float std_2 = img.computeStd();
		if ((std_1 == 0) || (std_2 == 0))
			return 0;
		std_i = (float)(1.0 / (std_1 * std_2));
		for (int i = 0; i < width; i++)
			for (int j = 0; j < height; j++)
				cc += (this.img[i][j]-mean_1) * (img.img[i][j]-mean_2);
		return (cc * std_i) / (this.width * this.height);
	}
	
	/**
	 * Almacena la imagen en formato PNG
	 * @param file_path ruta (terminada en .png) donde guardar la imagen
	 */
	public void save(String file_path) {//guarda en disco
		int[] p = new int[1];
		int[][] img_ubyte = this.toUnsignedByte();
		BufferedImage buff_img = new BufferedImage(this.width, this.height, BufferedImage.TYPE_BYTE_GRAY);
		WritableRaster raster = buff_img.getRaster();
		for(int i = 0; i < this.width; i++) {
	        for(int j = 0; j < this.height; j++) {
	        	p[0] = img_ubyte[i][j];
	            raster.setPixel(i, j, p);
	        }
	    }
		try {
			ImageIO.write(buff_img, "png", new File(file_path));
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * @return una matriz de enteros para representar los p�xeles en el rango [0, 255] (byte sin signo)
	 */
	public int[][] toUnsignedByte(){
		int[][] hold_img = new int[this.width][this.height];
		// Computes maximum and minimum values
		float min = Float.MAX_VALUE;
		float max = Float.MIN_VALUE;
		for(int i = 0; i < this.width; i++)
	        for(int j = 0; j < this.height; j++) {
	            if (this.img[i][j] > max)
	            	max = this.img[i][j];
	            if (this.img[i][j] < min)
	            	min = this.img[i][j];
	        }
		// Linear map to fit 0-255 byte range
		float a = (float) (255.0 / (max - min));
		float b = (float) (-1.0 * a * min); 
		for(int i = 0; i < this.width; i++)
	        for(int j = 0; j < this.height; j++) 
	        	hold_img[i][j] = (int)(a * this.img[i][j] + b);
	    return hold_img;
	}
	
	/**
	 * Fuerza a que los valores de los p�xeles est�n zero nomralizados (media 0 y desviaci�n est�ndar 1)
	 */
	public void zeroNormalization() {
		float mean = this.computeMean();
		float std = this.computeStd();
		for (int i=0; i<this.img.length; i++) 
			for (int j=0; j<this.img[i].length; j++)
				this.img[i][j] = (this.img[i][j] - mean) / std;
	}
	
	/**
	 * @return devluelve el valor medio de los niveles de gris (p�xeles)
	 */
	private float computeMean() {
		float total = 0;
		for (int i=0; i<this.width; i++) 
			for (int j=0; j<this.height; j++)
				total += this.img[i][j];
		return total / (this.width * this.height);
	}
	
	/**
	 * @return calcular la desviaci�n est�ndar de los p�xeles
	 */
	private float computeStd() {
		float hold;
		float total = 0;
		float mean = this.computeMean();
		for (int i=0; i<this.width; i++) 
			for (int j=0; j<this.height; j++) {
				hold = (this.img[i][j] - mean);
				total += hold * hold;
			}
		return (float) Math.sqrt(total / (this.width * this.height));
	}
	
	/**
	 * @return genera una copia de esta imagen
	 */
	public Imagen copy() {
		Imagen hold_img = new Imagen(this.width, this.height);
		hold_img.addSignal(this);
		return hold_img;
	}

}
