//PROBLEMA 5: MAXIMIZAR N�MERO DE FICHEROS EN UN DISCO
//CARGA �PTIMA (maximiza el n�mero de ficheros cargados)



/* Este programa resuelve el problema mediante el devorador:
"mientras quepan, cargar de menor a mayor" */

public class FicherosDiscoOptimo
{
static int capacidad; //capacidad disco en KBytes
static int[]tam;     // tama�o de los ficheros en KBytes

public static void main (String arg [] )
{
capacidad=Integer.parseInt(arg[0]);

int n=10; // n�mero ficheros 

tam=new int[n];
// SE SUPONE YA ORDENADOS CRECIENTEMENTE POR TAMA�O
// SI NO LO ESTUVIERAN, HABR�A QUE ORDENARLOS
tam[0]=50;tam[1]=100;tam[2]=200;tam[3]=350;tam[4]=370;
tam[5]=450;tam[6]=500;tam[7]=700;tam[8]=800;tam[9]=5000;

devorador(capacidad,tam);
} 

static void devorador (int capacidad,int[]tam)
// es de complejidad lineal con el n�mero ficheros 
{
System.out.println ("CAPACIDAD DEL DISCO EN KBytes= "+capacidad);
int n=tam.length;
int disponible=capacidad;
int cont=0;

while (cont<n && tam[cont]<=disponible)
 {
  System.out.println ("CARGA EL FICHERO="+tam[cont]+" KBytes");
  disponible=disponible-tam[cont];
  cont++;
 }
System.out.println ("NUMERO DE FICHEROS CARGADOS= "+cont);
System.out.println ("OPTIMIZA SIEMPRE EL NUMERO DE FICHEROS CARGADOS");
}

}
