//PROBLEMA 10: C�LCULO DEL GRAFO CONEXO DE COSTE M�NIMO
//ALGORITMO DE PRIM



public class Prim
{
	static String[]v;  //vector de nodos
	static int [][]w;  //matriz pesos sim�trica
	static int [][]sol;//aristas soluci�n

	public static void main (String arg [] )
	{
		int n=5;
		v=new String[n];
		for (int i=0;i<n;i++)
			v[i]="NODO"+i;

		w=new int[n][n];

		sol= new int[n-1][2];

		rellenaPesos(w);
		escribePesos(w); 

		int costemin=devoradorPrim(w,sol);

		System.out.println ("LAS ARISTAS DEL GRAFO COSTE MINIMO SON:");
		escribeSolucion(sol);
		System.out.println ("SU COSTE ES="+ costemin);
	} //de main


	public static int devoradorPrim (int[][]w,int[][]sol)
	/* este m�todo es iterativo y su complejidad temporal es c�bica O(n^3)
	   SE PODR�A IMPLEMENTAR CON COMPLEJIDAD O(n^2logn )
	   como en el libro base, pero es bastante m�s dif�cil */ 
	{
		int n=w.length;
		boolean[]marca=new boolean[n]; // nodos ya conectados
		for (int k=0;k<n;k++) marca[k]=false; 

		marca[0]=true;//salimos de cualquiera, p.e. el primero

		int coste=0;  //coste grafo m�nimo 

		for (int i=0;i<=n-2;i++)  // n-1 aristas
		{
			int min=Integer.MAX_VALUE;
			int origen=-1;
			int destino=-1; 
			for (int j=0;j<n;j++)
				for (int k=0;k<n;k++)
					if (marca[j] && !marca[k] && w[j][k]<min)
						// arista entre nodo ya conectado con otro todav�a no 
					{min=w[j][k];
					origen=j;
					destino=k;
					}
			coste=coste+min; 
			sol[i][0]=origen;
			sol[i][1]=destino;
			marca[destino]=true;  
		} 
		return coste;
		// retorma coste del grafo m�nimo de (n-1) aristas
	}     


	public static void  rellenaPesos(int[][]w)
	/* carga la matriz de costes ejemplo */
	{
		w[0][1]=7;w[1][0]=7;w[0][2]=9;w[2][0]=9;
		w[0][3]=8;w[3][0]=8;w[0][4]=8;w[4][0]=8;
		w[1][2]=6;w[2][1]=6;w[1][3]=5;w[3][1]=5;
		w[1][4]=4;w[4][1]=4;w[2][3]=3;w[3][2]=3;
		w[2][4]=8;w[4][2]=8;w[3][4]=6;w[4][3]=6;
		for (int i=0;i<w.length;i++)
			w[i][i]=Integer.MAX_VALUE;
	}   

	public static void escribePesos (int[][]w)
	/* escribe la matriz de costes */
	{
		int n=w.length;
		for (int i=0; i<n; i++)
		{
			for (int j=0; j<n; j++)
				if (w[i][j]==Integer.MAX_VALUE)
					System.out.print("-*");
				else
					System.out.print (w[i][j]+"*");
			System.out.println ();
		}
		System.out.println ();
	}  


	public static void escribeSolucion(int[][]sol)
	/* escribe las aristas del grafo �ptimo */
	{
		for (int i=0;i<sol.length;i++)
			System.out.println (v[sol[i][0]]+"--"+v[sol[i][1]]);
		System.out.println ();
	}   
}