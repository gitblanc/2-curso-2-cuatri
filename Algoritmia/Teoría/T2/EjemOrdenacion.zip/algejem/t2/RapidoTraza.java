/** Este programa sirve para ordenar n elementos
	con el algoritmo mejor. Es el QUICKSORT
 */
public class RapidoTraza
{
	static boolean traza= true;	// para mostrar traza paso a paso
	static int []v;		// vector sobre el que trabajamos

	public static void main (String arg [] )
	{
		int n;
		boolean automatico= false;
		
		if (arg.length==1)	// nos pasan un par�metro 
		{
			n= Integer.parseInt (arg[0]);  //para crear el vector con esos elementos de forma autom�tica  
			v = new int [n] ;
			automatico= true;
		}

		System.out.println("********************* QUICKSORT *********************");
		if (!automatico)
		{
			int[] aux= {3, 5, 1, 6, 9, 2, 7, 8, 4};
			v= aux;
			
			System.out.println ("Vector a ordenar es: ");
			Vector.mostrar (v);	
			rapido(v);
			System.out.println ("--> Vector ordenado es:");
			Vector.mostrar (v);
		}
		else
		{
		Vector.ordenDirecto (v);
		System.out.println ("VECTOR A ORDENAR ES");
		Vector.mostrar (v);	
		rapido(v);
		System.out.println ("VECTOR ORDENADO ES");
		Vector.mostrar (v);

		Vector.ordenInverso (v);
		System.out.println ("VECTOR A ORDENAR ES");
		Vector.mostrar (v);	
		rapido(v);
		System.out.println ("VECTOR ORDENADO ES");
		Vector.mostrar (v);

		Vector.aleatorio (v);
		System.out.println ("VECTOR A ORDENAR ES");
		Vector.mostrar (v);	
		imprimirArray(v,0,v.length-1,0);
		rapido(v);
		imprimirArray(v,0,v.length-1,0);
		System.out.println ("--> VECTOR ORDENADO ES");
		Vector.mostrar (v);
		}
	} // fin de main

	/**
	 * intercambiar los elementos de las posiciones i, j en el array a
	 * es O(1)
	 */
	private static void intercambiar (int[] v, int i, int j)
	{
		int t;
		t=v[i];v[i]=v[j];v[j]=t;
	}

	/** Deja el	pivote en una posicion tal que a su izquierda no 
		hay ning�n mayor, ni a la derecha ningun menor.
		Es un proceso lineal O(n).  
	 */
	private static int particion(int[]v,int iz,int de) 
	{
		int i, pivote;
		// el pivote es el de centro y se cambia con el primero
		intercambiar (v, (iz+de)/2,iz);
		pivote= v[iz]; 
		System.out.println("Pivote= "+pivote);
		i= iz;
		for (int s= iz+1; s <= de; s++) 
			if (v[s] <= pivote) 
			{
				i++;
				intercambiar(v,i,s);
			}
		intercambiar(v,iz,i);//se restituye el pivote donde debe estar
		return i; // retorna la posicion en que queda el pivote 
	}

	/**
	 * Ordenaci�n por el m�todo r�pido (quicksort)
	 * M�todo divide y vencer�s de complejidad estudiada en clase
	 */  
	private static void rapirec (int[] v, int iz, int de, int nivel) 
	{
		int m;
		if (de>iz) 
		{
			m=particion(v,iz,de);
				/**/if (traza) {
					System.out.print("Izq: ");
					if (m-1>iz)
						imprimirArray(v,iz,m-1,nivel+1);
					else
						System.out.println("Nivel "+(nivel+1)+" - Vac�a ----");
				}
			rapirec(v,iz,m-1,nivel+1);
				/**/if (traza) {
					System.out.print("Der: ");
					if (de>m+1)
						imprimirArray(v,m+1,de,nivel+1);
					else
						System.out.println("Nivel "+(nivel+1)+" - Vac�a2 ----");
				}
			rapirec(v,m+1,de,nivel+1);
		}
	}

	public static void rapido (int[] v) 
	{
		rapirec(v,0,v.length-1,0);
	}
	
	private static void imprimirArray(int[] v, int iz, int de, int nivel)
	{
		System.out.print("Nivel "+nivel+" - ");
		for (int i= 0; i<v.length; i++)
		{
			if (i==iz) System.out.print("[");
			System.out.print(v[i]+"\t");
			if (i==de) System.out.print("]");
		}
		System.out.println("iz= "+iz+", de= "+de);
	}
} 
