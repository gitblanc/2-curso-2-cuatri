/** Este programa sirve para ordenar n elementos 
	con un algoritmo de los "malos" (cuadr�tico)� 
	Es la BURBUJA O INTERCAMBIO DIRECTO */
public class Burbuja
{
	static int []v;

	public static void main (String arg [] )
	{
		int n=Integer.parseInt(arg[0]);  //tama�o del problema  
		v = new int[n] ;

		System.out.println("\n==========================");
		Vector.ordenDirecto (v);
		System.out.println ("VECTOR A ORDENAR ES");
		Vector.escribe (v);	
		burbuja(v);
		System.out.println ("--> VECTOR ORDENADO ES");
		Vector.escribe (v);

		System.out.println("\n==========================");
		Vector.ordenInverso (v);
		System.out.println ("VECTOR A ORDENAR ES");
		Vector.escribe (v);	
		burbuja(v);
		System.out.println ("--> VECTOR ORDENADO ES");
		Vector.escribe (v);

		System.out.println("\n==========================");
		Vector.aleatorio (v,15);
		System.out.println ("VECTOR A ORDENAR ES");
		Vector.escribe (v);	
		burbuja(v);
		System.out.println ("--> VECTOR ORDENADO ES");
		Vector.escribe (v);

	} // fin de main

	/**
	 * intercambiar los elementos de las posiciones i, j en el array a
	 */
	private static void intercambiar (int[] a, int i, int j)
	{
		int t;
		t= a[i]; a[i]= a[j]; a[j]= t;
	}

	/**
	 * Ordenaci�n por el m�todo de Burbuja
	 * @param a array de enteros, despu�s de la llamada quedar� ordenado
	 */
	public static void burbuja (int[] a) 
	{
		int n= a.length;
		for (int i=0;i<=n-2;i++) 
		{
			for (int j=n-1;j>i;j--)
				if (a[j-1]>a[j])
					intercambiar (a,j-1,j);
		}
	}  
}