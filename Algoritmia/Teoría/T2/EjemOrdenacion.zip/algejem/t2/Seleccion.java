/** Este programa sirve para ordenar n elementos
	con un algoritmo de los "malos" (cuadr�tico)�
	es la SELECCION
 */
public class Seleccion
{
	static int []v;

	public static void main (String arg [] )
	{
		int n= Integer.parseInt (arg[0]);  //tama�o del problema  
		v = new int [n] ;

		System.out.println("\n==========================");
		Vector.ordenDirecto (v);
		System.out.println ("VECTOR A ORDENAR ES");
		Vector.escribe (v);	
		seleccion(v);
		System.out.println ("--> VECTOR ORDENADO ES");
		Vector.escribe (v);

		System.out.println("\n==========================");
		Vector.ordenInverso (v);
		System.out.println ("VECTOR A ORDENAR ES");
		Vector.escribe (v);	
		seleccion(v);
		System.out.println ("--> VECTOR ORDENADO ES");
		Vector.escribe (v);

		System.out.println("\n==========================");
		Vector.aleatorio (v,15);
		System.out.println ("VECTOR A ORDENAR ES");
		Vector.escribe (v);	
		seleccion(v);
		System.out.println ("--> VECTOR ORDENADO ES");
		Vector.escribe (v);
	} // fin de main

	/**
	 * Intercambiar los elementos de las posiciones i, j en el array v
	 *  
	 */
	private static void Intercambiar (int[] v, int i, int j)
	{
		int t;
		t= v[i]; v[i]= v[j]; v[j]= t;
	}

	/**
	 * Ordenaci�n por selecci�n
	 * @param a array de enteros, despu�s de la llamada quedar� ordenado
	 */
	public static void seleccion (int[] a) 
	{
		int n= a.length;
		int posmin;
		for (int i=0;i<n-1;i++) 
		{
			// Buscar la posicion del mas peque�o de los que quedan
			posmin= i;
			for (int j= i+1; j < n; j++)
				if (a[j] < a[posmin])
					posmin= j;
				System.out.print(posmin+" -> ");
			// Intercambia el que toca con el m�s peque�o
			Intercambiar (a,i,posmin);
		Vector.escribe (v);	

		}  // for
	}  
} 
