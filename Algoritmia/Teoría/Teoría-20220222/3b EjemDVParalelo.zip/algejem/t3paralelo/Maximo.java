import java.util.Random;


/**
 * Calcula el m�ximo de un array[14] 
 *
 */
public class Maximo {
	private int inicio, fin, resultado, array[];
	
	/**
	 * Constructor
	 * @param array		vector de elementos
	 * @param inicio	posici�n a partir de la que buscamos
	 * @param fin		posici�n hasta la que buscamos
	 */
	private Maximo(int[] array, int inicio, int fin) {
		this.array= array;
		this.inicio= inicio;
		this.fin= fin;
	}

	static Random rnd = new Random();       // Generador de n�meros aleatorios
	
    /** 
     * M�todo (est�tico) para crear un vector de n�meros enteros aleatorios
	 */
    public static int[] getVector(int N) { 
        int[] v = new int[N];
        for(int i=0; i<N; i++) v[i]=rnd.nextInt(2*N);
        return v;
    }
     
    /**
     * M�todo p�blico para buscar el m�ximo,
     * llama al m�todo recursivo
     */
    public void calcularMax() {
		resultado= calcularMax(inicio,fin);
	}
	
	/**
	 * M�todo divide y vencer�s (recursivo) para buscar el m�ximo
	 * @param inicio	posici�n de inicio para la b�squeda
	 * @param fin		posici�n final para la b�squeda
	 * @return			devuelve el m�ximo del subvector
	 */
    private int calcularMax(int inicio, int fin) {
		if (fin-inicio==1) {
			return array[inicio];
		}
		else {
			int mitad= (inicio+fin)/2;
			
			int maximo1= calcularMax(inicio, mitad);
			int maximo2= calcularMax(mitad, fin);
			
			return Math.max(maximo1, maximo2);
		}
		
	}
    
    /**
     * Prueba de ejecuci�n y medici�n de tiempos
     * @param args No utilizamos este par�metro
     */
    public static void main(String[] args) {
    	int tam= 200000;
    	int[] array= getVector(tam);
    	
    	System.out.println("M�ximo de un vector aleatorio");
		Maximo maximo= new Maximo(array, 0, array.length);
		
        long  t1 = System.currentTimeMillis();              // Tiempo de inicio del proceso
		maximo.calcularMax();
		long  t2 = System.currentTimeMillis();              // Tiempo final del proceso
		double t = (t2-t1)/1000.0;                          // Tiempo real
		System.out.printf("%,20d %20.4f %n", tam, t);      // Tama�o del vector y el tiempo requerido para ordenarlo con el viejo modelo
		
		System.out.println("El m�ximo es: "+maximo.resultado);
		
    	
    }
	
}

