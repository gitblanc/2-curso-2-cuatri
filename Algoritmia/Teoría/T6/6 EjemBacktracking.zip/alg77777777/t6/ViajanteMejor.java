// PROBLEMA 6 : VIAJANTE DE COMERCIO (Ciclo de Hamilton)
// Ciclo que comprenda todos los nodos de un grafo sin repetir con un menor coste
// SE CALCULAN TODOS LOS CICLOS POSIBLES, 
// PARA ASÍ SABER EL MEJOR U ÓPTIMO
// Tiempo factorial (INTRATABLE)
// Ver contador de nodos explorados para comparar

package alg77777777.t6;

public class ViajanteMejor
{
	static int n;		// Número de nodos
	static String []v;	// Identificación de los nodos
	static int[][]w;	// Matriz de costes del camino entre todos los nodos
	static int origen;	// Identificación del nodo origen
	
	static boolean [] marca;	// Permite marcar nodos como visitados
	static int[] camino;	// Vector que va guardando el camino
	static int coste;		// Coste del camino construido
	static int longitud;	// Número de nodos que componen el camino construido

	static int[]caminoMejor;// para anotar el ciclo mejor
	static int costeMejor;  // coste del ciclo mejor

	static long contNodos= 0;	// Contador de nodos explorados

	public static void main (String arg[])
	{
		System.out.println("Problema del viajante");
		// Establecemos condiciones iniciales del problema
		n= 7;	// Recorrer n nodos
		v= new String[n];
		darValorNodos();	// Carga identificadores de nodos por código

		w=new int[n][n];
		darValorPesos();	// carga matriz de pesos por código
		escribirPesos();

		origen=0; // fijamos el nodo origen

		// Inicializamos arrays que utilizaremos para la resolución del problema
		marca=new boolean[n];	// matriz de nodos visitados
		for (int j=0;j<n;j++) marca[j]=false;

		camino =new int [n+1];	// matriz para guardar el camino
		camino[0]=origen;		// metemos el origen como primer nodo; pero no lo marcamos para poder regresar
		longitud=0;  			// longitud y coste iniciales 0
		coste=0;

		// Para guardar la solución óptima
		caminoMejor =new int [n+1];
		costeMejor= Integer.MAX_VALUE; // infinito 

		// llamada a backtracking
		backtracking (origen);
		
		escribirSolucion();

	} // fin de método main 


	/** Carga la matriz de costes ejemplo */
	public static void  darValorPesos()
	{
		w[0][1]=12;w[1][0]=12;w[0][2]=43;w[2][0]=43;
		w[0][3]=99;w[3][0]=99;w[0][4]=57;w[4][0]=57;
		w[0][5]=32;w[5][0]=32;w[0][6]=78;w[6][0]=78;
		w[1][2]=10;w[2][1]=10;w[1][3]=80;w[3][1]=80;
		w[1][4]=93;w[4][1]=93;w[1][5]=33;w[5][1]=33;
		w[1][6]=11;w[6][1]=11;w[2][3]=60;w[3][2]=60;
		w[2][4]=43;w[4][2]=43;w[2][5]=20;w[5][2]=20;
		w[2][6]=22;w[6][2]=22;w[3][4]=50;w[4][3]=50;
		w[3][5]=18;w[5][3]=18;w[3][6]=31;w[6][3]=31;
		w[4][5]=31;w[5][4]=31;w[4][6]=73;w[6][4]=73;
		w[5][6]=22;w[6][5]=22;
		for (int i=0;i<w.length;i++)
			w[i][i]=Integer.MAX_VALUE;
	}   

	static void darValorNodos()
	{
		for (int i=0;i<n;i++)
			v[i]= "Nodo "+i;

		System.out.println ("Los nodos se llaman así:");
		for (int i=0;i<n;i++)
			System.out.println(v[i]);
	}

	static void escribirPesos()
	{
		System.out.println ("La matriz de pesos es: ");
		for (int i=0;i<n;i++)
		{
			for (int j=0;j<n;j++)
				if (Integer.MAX_VALUE == w[i][j])
					System.out.print("INF\t");
				else
					System.out.print(w[i][j]+"\t");
			System.out.println();
		}   
	}

	/** Escribe solución calculada: camino y coste */
	static void escribirSolucion()
	{		
		System.out.println("El ciclo de Hamilton es:");
		for (int l=0;l<=n;l++)
			System.out.print(v[caminoMejor[l]]+" - ");
		System.out.println();
		System.out.println("Su coste es = "+ costeMejor);
		System.out.println("Nodos explorados: "+contNodos);	// Muestra nodos explorados en el desarrollo algoritmo
	}

	static void backtracking(int actual)
	{
		if (longitud==n && actual==origen)  // Hemos metido todos los nodos y el último es el origen
		{  
			if (coste<costeMejor)
			{
				for (int l=0;l<=longitud;l++) 
					caminoMejor[l]=camino[l];
				costeMejor=coste;
			}
		}
		else
			for (int j=0; j<n; j++)
				if(!marca[j]) // comprueba que no haya sido utilizado antes
				{
					contNodos++;	// cuenta nodos explorados
					longitud++;
					coste=coste+w[actual][j];
					marca[j]=true;
					camino[longitud]=j;
					backtracking(j);  // llamada sobre el hijo j 
					longitud--;
					coste=coste-w[actual][j];
					marca[j]=false;
				}
	}  // fin de backtracking

} // de clase

