import numpy as np

a = np.array([1,3,7])
print('\na = ')
print(a)
b = np.array([[2,4,3],[0,1,6]])
print('\nb = ')
print(b)
c = np.zeros((3,2))
print('\nc = ')
print(c)
d = np.ones((3,4))
print('\nd = ')		
print(d)