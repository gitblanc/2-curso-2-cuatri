# -*- coding: utf-8 -*-
"""
Created on Tue Mar 16 15:31:06 2021

@author: rodri
"""
import numpy as np
#%%
def puntoFijo(g,x0,tol=1.e-6,maxiter=200):
    